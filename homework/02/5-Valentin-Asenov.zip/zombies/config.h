#define MINER_COST       100
#define HEALTH           100
#define STARTING_GOLD    100
#define STARTING_SOLD    50
#define STARTING_ZOMB    1
#define SOLDIER_COST     10
#define ZOMBIE_START_POS 1
#define ZOMBIE_CHANGE    2