#include <stdio.h>

#define STARTING_SCV 5
#define STARTING_MINERALS 0
#define MINERAL_BLOCKS 2
#define MINERALS_PER_BLOCK 500
#define MINERALS_PER_MINE 8
#define MAX_PEOPLE 200
#define SOLDIER_COST 50
#define SCV_COST 50

#define red() printf("\033[1;31m")
#define yellow() printf("\033[0;33m")
#define green() printf("\033[0;32m")
#define cyan() printf("\033[0;36m")
#define reset() printf("\033[0m")